/*
  LUCIA HL - ESP32 firmware
  Board : DOIT ESP32 DEVKIT V1
  Relay : IN -> GPIO 18, VCC -> VIN, GND -> GND

  Controls: Android app (HTTP /on /off /status) AND Blynk button on V0.
  Both control the same relay.
  Wi-Fi auto-reconnects. Local HTTP control works even if internet/Blynk is down.

  Library needed: "Blynk" by Volodymyr Shymanskyy (Arduino Library Manager)
*/

// ---- Blynk settings (must be BEFORE the Blynk include) ----
#define BLYNK_TEMPLATE_ID   "TMPL6mu_d42wo"
#define BLYNK_TEMPLATE_NAME "LUCIA HL"
#define BLYNK_AUTH_TOKEN    "PASTE_YOUR_BLYNK_TOKEN_HERE"   // <-- put YOUR token here

#include <WiFi.h>
#include <WebServer.h>
#include <BlynkSimpleEsp32.h>

// ---- Wi-Fi settings ----
const char* WIFI_SSID = "YOUR_WIFI_NAME";       // <-- change
const char* WIFI_PASS = "YOUR_WIFI_PASSWORD";   // <-- change

#define RELAY_PIN 18

WebServer server(80);
bool relayState = false;                 // false = OFF, true = ON
unsigned long lastWifiTry = 0;
unsigned long lastBlynkTry = 0;

// ---- Relay logic: EXACTLY as tested, do not change ----
void relayOn() {
  digitalWrite(18, LOW);
  pinMode(18, OUTPUT);
}

void relayOff() {
  pinMode(18, INPUT);
}

// One function used by BOTH the app and Blynk
void setRelay(bool on) {
  if (on) relayOn(); else relayOff();
  relayState = on;
  if (Blynk.connected()) Blynk.virtualWrite(V0, on ? 1 : 0);   // keep Blynk button in sync
}

// ---- Blynk button (V0) ----
BLYNK_WRITE(V0) {
  setRelay(param.asInt() == 1);
}

BLYNK_CONNECTED() {
  Blynk.virtualWrite(V0, relayState ? 1 : 0);
}

// ---- HTTP endpoints ----
void sendStatus() {
  String json = String("{\"relay\":\"") + (relayState ? "ON" : "OFF") +
                "\",\"wifi\":\"connected\",\"rssi\":" + WiFi.RSSI() + "}";
  server.send(200, "application/json", json);
}

void handleOn()     { setRelay(true);  sendStatus(); }
void handleOff()    { setRelay(false); sendStatus(); }
void handleStatus() { sendStatus(); }

void connectWifi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
}

void setup() {
  Serial.begin(115200);
  relayOff();                       // relay OFF at power-up

  WiFi.persistent(false);
  WiFi.setAutoReconnect(true);
  connectWifi();

  Serial.print("Connecting to Wi-Fi");
  unsigned long t = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t < 15000) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  Serial.print("ESP32 IP address: ");
  Serial.println(WiFi.localIP());   // type this IP in the Android app

  server.on("/on", handleOn);
  server.on("/off", handleOff);
  server.on("/status", handleStatus);
  server.begin();

  Blynk.config(BLYNK_AUTH_TOKEN);
}

void loop() {
  server.handleClient();

  // Wi-Fi auto-reconnect: if lost, try again every 10 seconds
  if (WiFi.status() != WL_CONNECTED) {
    if (millis() - lastWifiTry > 10000) {
      lastWifiTry = millis();
      Serial.println("Wi-Fi lost, reconnecting...");
      WiFi.disconnect();
      connectWifi();
    }
    return;
  }

  // Blynk (needs internet). Short timeout so it never blocks the app control.
  if (Blynk.connected()) {
    Blynk.run();
  } else if (millis() - lastBlynkTry > 15000) {
    lastBlynkTry = millis();
    Blynk.connect(3000);
  }
}
