package com.lucia.hl

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private var recognizer: SpeechRecognizer? = null

    private lateinit var btnMic: Button
    private lateinit var txtRelay: TextView
    private lateinit var txtEsp: TextView
    private lateinit var txtWifi: TextView
    private lateinit var txtVoice: TextView
    private lateinit var edtIp: EditText

    // Checks the ESP32 every 4 seconds while the app is open
    private val poller = object : Runnable {
        override fun run() {
            updateWifi()
            checkStatus()
            ui.postDelayed(this, 4000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("lucia", MODE_PRIVATE)

        btnMic = findViewById(R.id.btnMic)
        txtRelay = findViewById(R.id.txtRelay)
        txtEsp = findViewById(R.id.txtEsp)
        txtWifi = findViewById(R.id.txtWifi)
        txtVoice = findViewById(R.id.txtVoice)
        edtIp = findViewById(R.id.edtIp)

        edtIp.setText(prefs.getString("ip", "192.168.1.100"))

        findViewById<Button>(R.id.btnOn).setOnClickListener { sendCommand(true) }
        findViewById<Button>(R.id.btnOff).setOnClickListener { sendCommand(false) }
        findViewById<Button>(R.id.btnSave).setOnClickListener {
            prefs.edit().putString("ip", edtIp.text.toString().trim()).apply()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            checkStatus()
        }
        btnMic.setOnClickListener { startListening() }
    }

    override fun onResume() {
        super.onResume()
        ui.post(poller)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(poller)
        recognizer?.destroy()
        recognizer = null
    }

    // ---------- ESP32 communication ----------

    private fun ip() = prefs.getString("ip", "192.168.1.100") ?: "192.168.1.100"

    /** Calls http://<ip><path> in the background. Gives null if the ESP32 is not reachable. */
    private fun call(path: String, done: (String?) -> Unit) {
        val address = ip()
        io.execute {
            val result = try {
                val c = URL("http://$address$path").openConnection() as HttpURLConnection
                c.connectTimeout = 2500
                c.readTimeout = 2500
                val text = c.inputStream.bufferedReader().use { it.readText() }
                c.disconnect()
                text
            } catch (e: Exception) {
                null
            }
            ui.post { done(result) }
        }
    }

    private fun checkStatus() {
        call("/status") { r -> showEsp(r) }
    }

    private fun sendCommand(on: Boolean) {
        call(if (on) "/on" else "/off") { r ->
            showEsp(r)
            if (r == null) Toast.makeText(this, "ESP32 not reachable", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showEsp(reply: String?) {
        if (reply == null) {
            txtEsp.text = "ESP32: Offline"
            txtEsp.setTextColor(Color.parseColor("#C62828"))
            txtRelay.text = "Relay: unknown"
            txtRelay.setTextColor(Color.GRAY)
            return
        }
        txtEsp.text = "ESP32: Connected"
        txtEsp.setTextColor(Color.parseColor("#2E7D32"))
        val on = reply.contains("\"relay\":\"ON\"")
        txtRelay.text = if (on) "Relay: ON" else "Relay: OFF"
        txtRelay.setTextColor(Color.parseColor(if (on) "#2E7D32" else "#C62828"))
    }

    private fun updateWifi() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val wifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        txtWifi.text = if (wifi) "Wi-Fi: Connected" else "Wi-Fi: Not connected"
        txtWifi.setTextColor(Color.parseColor(if (wifi) "#2E7D32" else "#C62828"))
    }

    // ---------- Voice control ----------

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition not available on this phone", Toast.LENGTH_LONG).show()
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(listener)
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            it.startListening(intent)
        }
        btnMic.text = "🎤\nListening..."
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == 1 && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            Toast.makeText(this, "Microphone permission is needed for voice control", Toast.LENGTH_LONG).show()
        }
    }

    /** Returns true = ON, false = OFF, null = not understood */
    private fun parse(text: String): Boolean? {
        val s = text.lowercase()
        return when {
            Regex("\\boff\\b").containsMatchIn(s) -> false
            Regex("\\bon\\b").containsMatchIn(s) -> true
            else -> null
        }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            btnMic.text = "🎤\nTAP TO SPEAK"
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
            if (list.isEmpty()) return
            txtVoice.text = "Last voice command: \"${list[0]}\""
            for (heard in list) {
                val cmd = parse(heard)
                if (cmd != null) { sendCommand(cmd); return }
            }
            Toast.makeText(this@MainActivity, "Say: LUCIA ON or LUCIA OFF", Toast.LENGTH_SHORT).show()
        }

        override fun onPartialResults(partial: Bundle?) {
            val p = partial?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (!p.isNullOrEmpty()) txtVoice.text = "Hearing: \"${p[0]}\""
        }

        override fun onError(error: Int) {
            btnMic.text = "🎤\nTAP TO SPEAK"
            txtVoice.text = "Last voice command: (didn't catch that, try again)"
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }
}
